import { createApp, watch } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import { i18n, locale, translate } from './i18n'
import HomePage from './views/HomePage.vue'
const LegalPage = () => import('./views/LegalPage.vue')
const AboutPage = () => import('./views/AboutPage.vue')
const FAQPage = () => import('./views/FAQPage.vue')
const ContactPage = () => import('./views/ContactPage.vue')
const HowBookingWorksPage = () => import('./views/HowBookingWorksPage.vue')
const JourneysPage = () => import('./views/JourneysPage.vue')
const JourneyDetailsPage = () => import('./views/JourneyDetailsPage.vue')
import { journeyDetails } from './data/journeyDetails'
import { initializeTheme } from './theme'
import './styles.css'
import './journey-details.css'
import './refinements.css'
import './typography.css'
import './legal.css'

initializeTheme()

const router = createRouter({
  history: createWebHistory(),
  scrollBehavior(to, from, savedPosition) {
    if (to.path === from.path) return false
    if (savedPosition) return savedPosition
    if (to.name === 'journeys') {
      try { return { top: JSON.parse(sessionStorage.getItem('journeys-browse') || '{}').scroll || 0, behavior: 'instant' } } catch {}
    }
    if (to.hash) return { el: to.hash }
    return { top: 0, behavior: 'instant' }
  },
  routes: [
    { path: '/privacy-policy', name: 'privacy-policy', component: LegalPage, meta: { title: 'Privacy Policy', legalKey: 'privacy' } },
    { path: '/terms-and-conditions', name: 'terms-and-conditions', component: LegalPage, meta: { title: 'Terms & Conditions', legalKey: 'terms' } },
    { path: '/', name: 'home', component: HomePage, meta: { title: 'TheVTravel — Journeys across Egypt' } },
    { path: '/about', name: 'about', component: AboutPage, meta: { title: 'About TheVTravel — Egypt, planned with local care' } },
    { path: '/faq', name: 'faq', component: FAQPage, meta: { title: 'Frequently Asked Questions — TheVTravel' } },
    { path: '/contact', name: 'contact', component: ContactPage, meta: { title: 'Contact Us — TheVTravel' } },
    { path: '/how-booking-works', name: 'how-booking-works', component: HowBookingWorksPage, meta: { title: 'How Booking Works — TheVTravel' } },
    { path: '/journeys/:slug', name: 'journey-details', component: JourneyDetailsPage, meta: { title: 'Journey Details — TheVTravel' } },
    { path: '/journeys', name: 'journeys', component: JourneysPage, meta: { title: 'All Journeys — TheVTravel' } },
  ],
})

function updateTitle(to = router.currentRoute.value) {
  document.title = to.name === 'journey-details' && journeyDetails[to.params.slug] ? `${translate(journeyDetails[to.params.slug].title)} — TheVTravel` : translate(to.meta.title || 'TheVTravel')
}
router.afterEach(updateTitle)
watch(locale, () => updateTitle())

createApp(App).use(i18n).use(router).mount('#app')
