import { ref } from 'vue'
import messages from './data/demoTranslations.json'
export const supportedLanguages = Object.freeze([
  { code: 'en', label: 'English' }, { code: 'ru', label: 'Русский' },
  { code: 'fr', label: 'Français' }, { code: 'de', label: 'Deutsch' },
])
const stored = localStorage.getItem('thevtravel-language')
export const locale = ref(supportedLanguages.some(language => language.code === stored) ? stored : 'en')
export function setLocale(code) {
  if (!supportedLanguages.some(language => language.code === code)) return
  locale.value = code
  localStorage.setItem('thevtravel-language', code)
  document.documentElement.lang = code
}
setLocale(locale.value)
// English keys are demo fallbacks. API records may supply { en, ru, fr, de } instead.
export function translate(value, parameters) {
  if (value === null || value === undefined) return ''
  if (typeof value === 'object') return value[locale.value] || value.en || ''
  if (typeof value !== 'string') return value
  if (parameters) {
    const template = locale.value === 'en' ? value : messages[value]?.[locale.value] || value
    return template.replace(/\{(\w+)\}/g, (_, name) => parameters[name] ?? '')
  }
  if (locale.value === 'en') return value
  const key = value.trim().replace(/\s+/g, ' ')
  const translated = messages[key]?.[locale.value]
  if (translated) return translated
  // Composite metadata and accessible labels retain their dynamic data.
  const duration = key.match(/^(~\s*)?([\d–−.,]+)\s+hours$/)
  if (duration) return `${duration[1] || ''}${duration[2]} ${messages.hours[locale.value]}`
  return value
}
export const i18n = { install(app) { app.config.globalProperties.$t = translate } }
