import { ref } from 'vue'
// One existing transfer flow instance is owned by GlobalFloatingActions.
export const transferRequested = ref(0)
export function requestTransfer() { transferRequested.value++ }
