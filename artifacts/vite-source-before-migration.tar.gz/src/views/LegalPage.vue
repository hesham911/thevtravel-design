<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import LegalContentPage from '../components/LegalContentPage.vue'
import { legalPages } from '../data/legalPages'
const route = useRoute()
const content = computed(() => legalPages[route.meta.legalKey])
</script>
<template><LegalContentPage :content="content" /></template>
